import base from './base.yaml'
import server from './server'
import settings from './settings.yaml'
import stage from './stage.yaml'
import tamagotchi from './tamagotchi'
import wowCompanion from './wow-companion.yaml'

export default {
  base,
  server,
  settings,
  stage,
  tamagotchi,
  'wow-companion': wowCompanion,
}
