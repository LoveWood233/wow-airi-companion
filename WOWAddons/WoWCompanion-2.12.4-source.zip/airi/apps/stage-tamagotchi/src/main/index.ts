import type { BrowserWindow } from 'electron'

import type { FullscreenMode, FullscreenSurfaceId } from '../shared/eventa'
import type { FileLoggerHandle } from './app/file-logger'
import type { SettingsWindowManager } from './windows/settings'
import type { FullscreenPlace } from './windows/shared/fullscreen'
import type { WorkspaceWindowManager } from './windows/workspace'

import process, { env, platform } from 'node:process'

import { mkdirSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

import messages from '@proj-airi/i18n/locales'

import { electronApp, is, optimizer } from '@electron-toolkit/utils'
import { Format, LogLevel, setGlobalFormat, setGlobalHookPostLog, setGlobalLogLevel, useLogg } from '@guiiai/logg'
import { createContext } from '@moeru/eventa/adapters/electron/main'
import { hasSelectedScreenCaptureSource, initScreenCaptureForMain } from '@proj-airi/electron-screen-capture/main'
import { app, ipcMain, protocol, session } from 'electron'
import { noop } from 'es-toolkit'
import { createLoggLogger, injeca, lifecycle } from 'injeca'
import { isLinux } from 'std-env'

import devIcon from '../../resources/icon-dev.png?asset'

import { openDebugger, setupDebugger } from './app/debugger'
import { nullFileLoggerHandle, setupFileLogger } from './app/file-logger'
import { resolveIsWayland } from './app/ozone'
import { installSingleInstanceGuard } from './app/single-instance'
import { createArtistryConfig } from './configs/artistry'
import { createGlobalAppConfig } from './configs/global'
import { createIOTraceRecordingConfig } from './configs/io-trace-recording'
import { emitAppBeforeQuit, emitAppWindowAllClosed } from './libs/bootkit/lifecycle'
import { getElectronMainDirname, setElectronMainDirname } from './libs/electron/location'
import { createI18n } from './libs/i18n'
import { setupAppleSpeechTranscriptionService } from './services/airi/apple-speech-transcription'
import { setupAppleVisionService } from './services/airi/apple-vision'
import { setupServerChannel } from './services/airi/channel-server'
import { setupComputerUse } from './services/airi/computer-use'
import { setupGodotStageManager } from './services/airi/godot-stage'
import { setupHomeAssistant } from './services/airi/home-assistant'
import { setupBuiltInServer } from './services/airi/http-server'
import { IOTraceRecordingService } from './services/airi/io-trace-recording'
import { setupMcpManager } from './services/airi/mcp-servers'
import { setupExtensionHost } from './services/airi/plugins'
import { setupArtistryBridge } from './services/airi/widgets/artistry-bridge'
import { setupWowCompanion } from './services/airi/wow-companion'
import { setupAutoUpdater } from './services/electron/auto-updater'
import { setupSherpawModelAssetsProtocol } from './services/electron/bundled-sherpaw-assets'
import { setupGlobalShortcutService } from './services/electron/global-shortcut'
import { setupPermissionHandlers } from './services/electron/media-permissions'
import { setupSherpawModelAssets } from './services/electron/sherpaw-model-assets'
import { setupTray } from './tray'
import { setupAboutWindowReusable } from './windows/about'
import { setupBeatSync } from './windows/beat-sync'
import { setupCaptionWindowManager } from './windows/caption'
import { setupChatWindowManager } from './windows/chat'
import { isDesktopOverlayEnabled, setupDesktopOverlayWindow } from './windows/desktop-overlay'
import { setupDevtoolsWindow } from './windows/devtools'
import { setupEditorWindowManager } from './windows/editor'
import { setupInlayWindowReusable } from './windows/inlay'
import { setupMainWindow } from './windows/main'
import { setupNoticeWindowManager } from './windows/notice'
import { setupOnboardingWindowManager } from './windows/onboarding'
import { setupSettingsWindowReusableFunc } from './windows/settings'
import { moveFullscreen } from './windows/shared/fullscreen'
import { setupSpotlightWindowManager } from './windows/spotlight'
import { setupWidgetsWindowManager } from './windows/widgets'
import { setupWorkspaceWindowManager } from './windows/workspace'

// TODO: once we refactored eventa to support window-namespaced contexts,
// we can remove the setMaxListeners call below since eventa will be able to dispatch and
// manage events within eventa's context system.
ipcMain.setMaxListeners(100)

setElectronMainDirname(dirname(fileURLToPath(import.meta.url)))
protocol.registerSchemesAsPrivileged([{
  scheme: 'airi-model',
  privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true },
}, {
  scheme: 'airi-sherpaw',
  privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true },
}])
setGlobalFormat(Format.Pretty)
setGlobalLogLevel(LogLevel.Log)
setupDebugger()

const log = useLogg('main').useGlobalConfig()

const appUserDataPath = env.APP_USER_DATA_PATH?.trim()
if (appUserDataPath) {
  mkdirSync(appUserDataPath, { recursive: true })
  app.setPath('userData', appUserDataPath)
  // Browser storage and main-process records must use the same explicit profile.
  app.setPath('sessionData', appUserDataPath)
}

// Thanks to [@blurymind](https://github.com/blurymind),
//
// When running Electron on Linux, navigator.gpu.requestAdapter() fails.
// In order to enable WebGPU and process the shaders fast enough, we need the following
// command line switches to be set.
//
// https://github.com/electron/electron/issues/41763#issuecomment-2051725363
// https://github.com/electron/electron/issues/41763#issuecomment-3143338995
if (isLinux) {
  // NOTICE:
  // All enabled features must be joined into a single comma-separated string
  // instead of calling appendSwitch('enable-features', ...) once per feature.
  // Root cause: Chromium's commandLine stores switches by key, so each
  // appendSwitch('enable-features', ...) call overwrites the previous value and
  // only the last feature survives.
  // Source: Chromium base::CommandLine behavior; see
  // https://github.com/electron/electron/issues/41763 for the WebGPU setup this supports.
  // Removal condition: never for the join itself; this block can be deleted once
  // WebGPU works on Linux Electron without manual feature switches.
  const enabledFeatures = [
    'SharedArrayBuffer',
  ]

  app.commandLine.appendSwitch('enable-unsafe-webgpu')

  // Check explicit command-line switches before falling back to session environment variables.
  // When running with XWayland (e.g. '--ozone-platform=x11'), session variables like WAYLAND_DISPLAY
  // are still inherited from the Wayland desktop, but Chromium uses the explicitly specified Ozone backend.
  // Treat explicit 'auto' as an unresolved platform selection and resolve using session environment variables.
  const isWayland = resolveIsWayland({
    explicitOzonePlatform: app.commandLine.getSwitchValue('ozone-platform'),
    ozonePlatformHint: app.commandLine.getSwitchValue('ozone-platform-hint'),
    env,
  })

  if (isWayland) {
    enabledFeatures.push('GlobalShortcutsPortal', 'UseOzonePlatform', 'WaylandWindowDecorations')
    if (!app.commandLine.hasSwitch('ozone-platform-hint')) {
      app.commandLine.appendSwitch('ozone-platform-hint', 'auto')
    }
  }
  else {
    // NOTICE:
    // Vulkan must only be enabled on non-Wayland sessions, otherwise GPU
    // initialization fails or rendering glitches appear.
    // Root cause: Vulkan is incompatible with '--ozone-platform=wayland' in
    // Chromium's surface factory; the Wayland Ozone backend cannot present
    // Vulkan surfaces.
    // Source: Chromium Ozone/Wayland surface factory; workaround tracked via
    // https://github.com/electron/electron/issues/41763 (WebGPU on Linux).
    // Removal condition: when Chromium/Electron supports Vulkan with the Wayland
    // Ozone backend, drop the isWayland guard and always push 'Vulkan'.
    enabledFeatures.push('Vulkan')
  }

  app.commandLine.appendSwitch('enable-features', enabledFeatures.join(','))
}

// Packaged builds use the bundle icon (`build/icon.icon` or `build/icon.icns`).
// Dev runs use the Electron default icon, so replace it with a marked dev icon.
if (is.dev)
  app.dock?.setIcon(devIcon)
electronApp.setAppUserModelId('ai.moeru.airi')

// Track the real user-facing AIRI window because the process also owns hidden utility windows.
// The second-instance handler should restore the main UI instead of accidentally surfacing internals.
let userFacingMainWindow: BrowserWindow | undefined
let settingsWindowManager: SettingsWindowManager | undefined
let workspaceWindowManager: WorkspaceWindowManager | undefined
/** The fullscreen mode that the user chose, as the main window page reports it. */
let fullscreenMode: FullscreenMode = 'off'
/** Shows a surface in the fullscreen mode of the main window, and returns `false` unless the mode is `single-window`. */
let openFullscreenInMainWindow: ((surface: FullscreenSurfaceId, route?: string) => boolean) | undefined
/** The main window as a place of the fullscreen mode, once it exists. */
let mainWindowPlace: FullscreenPlace | undefined
/** Keeps the main window above the others, for the window of the `multi-window` mode that covers the screen under it. */
let keepMainWindowAbove: ((above: boolean) => void) | undefined
let extensionManagementWebContentsId: number | undefined

/** Opens settings where the fullscreen mode says: in the main window, in the window of the `multi-window` mode, or in the settings window. */
async function openSettings(route?: string) {
  if (openFullscreenInMainWindow?.('settings', route))
    return
  if (fullscreenMode === 'multi-window' && workspaceWindowManager) {
    await workspaceWindowManager.open('settings', route)
    return
  }
  await settingsWindowManager?.openWindow(route)
}

/** The settings window as a place of the fullscreen mode. It shows settings while the mode is off. */
const settingsWindowPlace: FullscreenPlace = {
  pack: async () => {
    const route = settingsWindowManager?.shownRoute()
    return route ? { surface: 'settings', surfaces: [{ id: 'settings', state: route }] } : undefined
  },
  close: async () => {
    settingsWindowManager?.closeWindow()
    return true
  },
  // Settings carry the route that shows. The settings window shows only settings, so other surfaces stay behind.
  open: async (pack) => {
    const settings = pack.surfaces.find(entry => entry.id === 'settings')
    if (settings)
      await settingsWindowManager?.openWindow(typeof settings.state === 'string' ? settings.state : undefined)
  },
}

/** The move in progress. Each change of the window mode waits for the move before it, so two moves never interleave. */
let fullscreenMove: Promise<void> = Promise.resolve()

/** The place where the fullscreen mode shows in a mode. */
function placeOf(mode: FullscreenMode): FullscreenPlace | undefined {
  if (mode === 'single-window')
    return mainWindowPlace
  if (mode === 'multi-window')
    return workspaceWindowManager?.place
  return settingsWindowPlace
}

/** Shows the chat in the fullscreen mode, in the window that the mode names. */
async function openFullscreenChat() {
  if (fullscreenMode === 'multi-window')
    await workspaceWindowManager?.open('chat')
  else
    openFullscreenInMainWindow?.('chat')
}

/** Lets only the window that shows the settings interface manage extensions, until that window closes. */
function trackExtensionManagementWindow(window: BrowserWindow) {
  const webContentsId = window.webContents.id
  extensionManagementWebContentsId = webContentsId
  window.once('closed', () => {
    if (extensionManagementWebContentsId === webContentsId)
      extensionManagementWebContentsId = undefined
  })
}
const shouldStartMainProcess = installSingleInstanceGuard({ app, getWindow: () => userFacingMainWindow })

if (shouldStartMainProcess) {
  initScreenCaptureForMain()
}

let fileLogger: FileLoggerHandle = nullFileLoggerHandle
let skipFileLogging = false

app.whenReady().then(async () => {
  if (!shouldStartMainProcess) {
    return
  }

  setupSherpawModelAssetsProtocol(resolve(getElectronMainDirname(), '..', 'renderer'))
  setupSherpawModelAssets(createContext(ipcMain).context)
  setupPermissionHandlers(session.defaultSession, hasSelectedScreenCaptureSource)

  // Initialize file logger and register the hook
  fileLogger = await setupFileLogger()

  // Register the global hook for file logging
  setGlobalHookPostLog((_, formatted) => {
    if (skipFileLogging || fileLogger.logFileFd === null)
      return
    void fileLogger.appendLog(formatted)
  })

  injeca.setLogger(createLoggLogger(useLogg('injeca').useGlobalConfig()))

  const appConfig = injeca.provide('configs:app', () => createGlobalAppConfig())
  const artistryConfig = injeca.provide('configs:artistry', () => createArtistryConfig())
  const ioTraceRecordingConfig = injeca.provide('configs:io-trace-recording', () => createIOTraceRecordingConfig())
  const electronApp = injeca.provide('host:electron:app', () => app)
  const autoUpdater = injeca.provide('services:auto-updater', {
    dependsOn: { appConfig },
    build: ({ dependsOn }) => setupAutoUpdater({
      enabled: import.meta.env.VITE_DISTRIBUTION !== 'steam',
      getStoredUpdateLane: () => dependsOn.appConfig.get()?.updateChannel,
      setStoredUpdateLane: (lane) => {
        const currentConfig = dependsOn.appConfig.get()
        dependsOn.appConfig.update({
          ...currentConfig,
          updateChannel: lane,
        })
      },
    }),
  })

  const i18n = injeca.provide('libs:i18n', {
    dependsOn: { appConfig },
    // Translated locales hold only the strings that are translated, so a missing
    // key shows English, as it does in the renderers.
    build: ({ dependsOn }) => createI18n({ messages, locale: dependsOn.appConfig.get()?.language, fallbackLocale: 'en' }),
  })

  const serverChannel = injeca.provide('modules:channel-server', {
    dependsOn: { app: electronApp, lifecycle },
    build: async ({ dependsOn }) => setupServerChannel(dependsOn),
  })

  const airiHttpServer = injeca.provide('modules:airi-http-server', {
    build: async () => setupBuiltInServer({ servers: [] }),
  })

  const godotStageManager = injeca.provide('modules:godot-stage-manager', {
    build: async () => setupGodotStageManager(),
  })

  const appleSpeechTranscription = injeca.provide('modules:apple-speech-transcription', {
    dependsOn: { lifecycle },
    build: ({ dependsOn }) => setupAppleSpeechTranscriptionService(dependsOn),
  })

  const appleVision = injeca.provide('modules:apple-vision', {
    dependsOn: { lifecycle },
    build: ({ dependsOn }) => setupAppleVisionService(dependsOn),
  })

  const mcpManager = injeca.provide('modules:mcp-manager', {
    build: async () => setupMcpManager(),
  })

  const ioTraceRecording = injeca.provide('services:io-trace-recording', {
    dependsOn: { config: ioTraceRecordingConfig, lifecycle },
    build: ({ dependsOn }) => {
      const service = new IOTraceRecordingService({
        directory: join(app.getPath('userData'), 'io-traces'),
        getStoredEnabled: () => dependsOn.config.get()?.enabled ?? false,
        setStoredEnabled: enabled => dependsOn.config.update({ enabled }),
      })
      dependsOn.lifecycle.appHooks.onStart(async () => {
        try {
          await service.restore()
        }
        catch (error) {
          log.withError(error).error('Failed to restore IO trace recording')
        }
      })
      dependsOn.lifecycle.appHooks.onStop(() => service.dispose())
      return service
    },
  })

  const widgetsManager = injeca.provide('windows:widgets', {
    dependsOn: { serverChannel, i18n },
    build: ({ dependsOn }) => setupWidgetsWindowManager(dependsOn),
  })

  const pluginHost = injeca.provide('modules:plugin-host', {
    dependsOn: { serverChannel, widgetsManager },
    build: ({ dependsOn }) => setupExtensionHost({
      ...dependsOn,
      getExtensionManagementWebContentsId: () => extensionManagementWebContentsId,
    }),
  })

  const globalShortcut = injeca.provide('services:global-shortcut', () => setupGlobalShortcutService())

  // Beat Sync uses a background renderer because Web Audio processing needs a DOM runtime.
  const beatSync = injeca.provide('windows:beat-sync', () => setupBeatSync())

  const devtoolsMarkdownStressWindow = injeca.provide('windows:devtools:markdown-stress', () => setupDevtoolsWindow())

  const onboardingWindowManager = injeca.provide('windows:onboarding', {
    dependsOn: { serverChannel, i18n },
    build: ({ dependsOn }) => setupOnboardingWindowManager(dependsOn),
  })

  const noticeWindow = injeca.provide('windows:notice', {
    dependsOn: { i18n, serverChannel },
    build: ({ dependsOn }) => setupNoticeWindowManager(dependsOn),
  })

  const aboutWindow = injeca.provide('windows:about', {
    dependsOn: { autoUpdater, i18n, serverChannel },
    build: ({ dependsOn }) => setupAboutWindowReusable(dependsOn),
  })
  const inlayWindow = injeca.provide('windows:inlay', {
    dependsOn: { i18n, serverChannel, globalShortcut },
    build: ({ dependsOn }) => setupInlayWindowReusable(dependsOn),
  })

  const chatWindow = injeca.provide('windows:chat', {
    dependsOn: { widgetsManager, serverChannel, mcpManager, i18n },
    build: ({ dependsOn }) => setupChatWindowManager({
      ...dependsOn,
      getMainWindow: () => userFacingMainWindow,
      // NOTICE:
      // Settings, the main window, and the fullscreen window depend on Chat
      // through injeca, so Chat cannot depend on them. They exist before any
      // window takes input, so Chat resolves them lazily.
      // Removal condition: none of them depends on Chat.
      openSettingsWindow: openSettings,
      openFullscreenChat,
    }),
  })

  const spotlightWindow = injeca.provide('windows:spotlight', {
    dependsOn: { serverChannel, i18n, chatWindow, globalShortcut, appConfig },
    build: ({ dependsOn }) => setupSpotlightWindowManager(dependsOn),
  })

  const editorWindow = injeca.provide('windows:editor', {
    dependsOn: { serverChannel, i18n },
    build: ({ dependsOn }) => setupEditorWindowManager(dependsOn),
  })

  const settingsWindow = injeca.provide('windows:settings', {
    dependsOn: { widgetsManager, beatSync, autoUpdater, devtoolsWindow: devtoolsMarkdownStressWindow, serverChannel, godotStageManager, mcpManager, i18n, globalShortcut, spotlightWindow, ioTraceRecording },
    build: async ({ dependsOn }) => {
      settingsWindowManager = setupSettingsWindowReusableFunc({
        ...dependsOn,
        getMainWindow: () => userFacingMainWindow,
        onWindowCreated: trackExtensionManagementWindow,
      })
      // Every settings entry point asks this manager, so the fullscreen mode decides here where settings open.
      return { ...settingsWindowManager, openWindow: openSettings }
    },
  })

  const workspaceWindow = injeca.provide('windows:workspace', {
    dependsOn: { chatWindow, widgetsManager, autoUpdater, devtoolsWindow: devtoolsMarkdownStressWindow, serverChannel, godotStageManager, mcpManager, i18n, globalShortcut, spotlightWindow, ioTraceRecording },
    build: ({ dependsOn }) => {
      workspaceWindowManager = setupWorkspaceWindowManager({
        ...dependsOn,
        getMainWindow: () => userFacingMainWindow,
        isActive: () => fullscreenMode === 'multi-window',
        openSettings,
        onWindowCreated: trackExtensionManagementWindow,
        // The window covers the screen, so the main window stays above it and the character stays in view.
        onOpenChange: open => keepMainWindowAbove?.(open),
      })
      return workspaceWindowManager
    },
  })

  const mainWindow = injeca.provide('windows:main', {
    dependsOn: { editorWindow, settingsWindow, workspaceWindow, chatWindow, widgetsManager, noticeWindow, beatSync, autoUpdater, serverChannel, godotStageManager, mcpManager, i18n, onboardingWindowManager, inlayWindow, appleSpeechTranscription, appleVision, ioTraceRecording, globalShortcut, spotlightWindow, devtoolsWindow: devtoolsMarkdownStressWindow },
    build: async ({ dependsOn }) => setupMainWindow({
      ...dependsOn,
      onWindowCreated: (window) => {
        userFacingMainWindow = window
      },
      onFullscreenOpener: (open) => {
        openFullscreenInMainWindow = open
      },
      // The plugin host lets only the settings interface manage extensions. Settings show in the fullscreen mode of
      // the main window, so while it lasts, that interface is the main window.
      // Settings can already show in another window when the main window leaves the mode. That window keeps the role.
      onFullscreenChange: (active) => {
        const mainWindowId = userFacingMainWindow?.webContents.id
        if (active)
          extensionManagementWebContentsId = mainWindowId
        else if (extensionManagementWebContentsId === mainWindowId)
          extensionManagementWebContentsId = undefined
      },
      onKeepAbove: (keepAbove) => {
        keepMainWindowAbove = keepAbove
      },
      onFullscreenPlace: (place) => {
        mainWindowPlace = place
      },
      // What the mode shows moves to the place of the new mode, with every surface and its state.
      onFullscreenModeChange: (mode, previous) => {
        fullscreenMode = mode
        fullscreenMove = fullscreenMove
          .then(() => moveFullscreen(placeOf(previous), placeOf(mode)))
          .catch(error => log.withError(error).error('Failed to move the fullscreen mode to the new window mode'))
      },
    }),
  })

  const captionWindow = injeca.provide('windows:caption', {
    dependsOn: { mainWindow, serverChannel, i18n },
    build: async ({ dependsOn }) => setupCaptionWindowManager(dependsOn),
  })

  const tray = injeca.provide('app:tray', {
    dependsOn: { mainWindow, settingsWindow, captionWindow, widgetsWindow: widgetsManager, serverChannel, beatSyncBgWindow: beatSync, aboutWindow, inlayWindow, i18n, appConfig },
    build: async ({ dependsOn }) => setupTray(dependsOn),
  })

  // Desktop grounding overlay — gated by AIRI_DESKTOP_OVERLAY=1
  if (isDesktopOverlayEnabled()) {
    const desktopOverlay = injeca.provide('windows:desktop-overlay', {
      dependsOn: { mcpManager, serverChannel, i18n },
      build: async ({ dependsOn }) => setupDesktopOverlayWindow(dependsOn),
    })

    // NOTICE: Separate invoke ensures the overlay is eagerly built.
    // Without this, injeca.start() would skip it because no other
    // provider depends on 'windows:desktop-overlay'.
    injeca.invoke({
      dependsOn: { desktopOverlay },
      callback: noop,
    })
  }

  injeca.invoke({
    dependsOn: { mainWindow, tray, serverChannel, airiHttpServer, godotStageManager, pluginHost, mcpManager, onboardingWindow: onboardingWindowManager, widgetsWindow: widgetsManager, spotlightWindow, artistryConfig },
    callback: async (deps) => {
      const { context } = createContext(ipcMain)
      setupComputerUse(context)
      setupHomeAssistant(context)
      setupWowCompanion(context)
      await setupArtistryBridge({
        widgetsManager: deps.widgetsWindow,
        context,
        artistryConfig: deps.artistryConfig,
      })
    },
  })

  injeca.start().catch(err => log.withError(err).error('Failed to start injeca'))

  // Extra
  openDebugger()

  // Default open or close DevTools by F12 in development
  // and ignore CommandOrControl + R in production.
  // see https://github.com/alex8088/electron-toolkit/tree/master/packages/utils
  app.on('browser-window-created', (_, window) => optimizer.watchWindowShortcuts(window))
}).catch((err) => {
  log.withError(err).error('Error during app initialization')
})

// Quit when all windows are closed, except on macOS. There, it's common
// for applications and their menu bar to stay active until the user quits
// explicitly with Cmd + Q.
app.on('window-all-closed', () => {
  emitAppWindowAllClosed()

  if (platform !== 'darwin') {
    app.quit()
  }
})

let appExiting = false

// Clean up server and intervals when app quits
async function handleAppExit() {
  if (appExiting)
    return

  appExiting = true

  let exitedNormally = true

  /**
   * Safely execute fn and log any errors that occur, marking the exit as abnormal
   * if an error is caught.
   *
   * @param operation - A verb phrase describing the operation.
   * @param fn - Any function to execute. It can be either sync or async.
   * @returns A promise that resolves when the operation is complete.
   */
  async function logIfError(operation: string, fn: () => unknown): Promise<void> {
    try {
      await fn()
    }
    catch (error) {
      exitedNormally = false
      log.withError(error).error(`[app-exit] Failed to ${operation}:`)
    }
  }

  await Promise.all([
    logIfError('execute onAppBeforeQuit hooks', () => emitAppBeforeQuit()),
    logIfError('stop injeca', () => injeca.stop()),
  ])

  // Prevent the global log hook from trying to write to the file after close() is called,
  // which would cause a recursive failure if close() itself throws.
  skipFileLogging = true
  await logIfError('flush file logs', () => fileLogger.close()) // Ensure all logs are flushed

  if (!exitedNormally) {
    app.exit(1)
  }
  else {
    app.quit()
  }
}

process.on('SIGINT', () => handleAppExit())

app.on('before-quit', (event) => {
  if (appExiting)
    return

  event.preventDefault()
  handleAppExit()
})
