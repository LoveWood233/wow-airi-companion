import type { Rectangle, SourcesOptions } from 'electron'

import type {
  ScreenAmbientLightCaptureStatus,
  ScreenAmbientLightDiagnosticsChannelEvent,
  ScreenAmbientLightDiagnosticsSnapshot,
} from '../../shared/screen-ambient-light-diagnostics'

import { errorMessageFrom } from '@moeru/std'
import { useElectronScreenCapture } from '@proj-airi/electron-screen-capture/vue'
import { getElectronEventaContext, useElectronAllDisplays, useElectronWindowBounds } from '@proj-airi/electron-vueuse'
import {
  ambientLightSampleFromHex,
  sampleScreenAmbientLight,
  smoothAmbientLightEnvironment,
  uniformAmbientLightEnvironment,
  wholeWindowRectangle,
} from '@proj-airi/stage-shared/screen-ambient-light'
import { useScreenAmbientLightEnvironment, useSettingsScreenAmbientLight } from '@proj-airi/stage-shared/stores/screen-ambient-light'
import { until, useBroadcastChannel, watchDebounced } from '@vueuse/core'
import { clamp } from 'es-toolkit'
import { storeToRefs } from 'pinia'
import { computed, onScopeDispose, shallowRef, watch } from 'vue'

import {
  screenAmbientLightDiagnosticsChannelName,
  screenAmbientLightDiagnosticsWatchMs,
} from '../../shared/screen-ambient-light-diagnostics'
import { findDominantDisplayArea } from '../../shared/utils/electron/display'
import { i18n } from '../modules/i18n'
import { useStagePaintedMask } from './use-stage-painted-mask'

const sourcesOptions: SourcesOptions = {
  types: ['screen'],
  thumbnailSize: { width: 0, height: 0 },
}

/**
 * Oversampling of the capture stream relative to the sample canvas.
 *
 * The stream is requested at this multiple of the sample width, so that the
 * canvas downscale averages a few source pixels per sample instead of picking
 * one. 4 keeps a 128-pixel sample at 512 pixels, which is small enough that the
 * per-frame readback costs well under a millisecond.
 */
const captureOversampling = 4
/**
 * Widest stream the capture asks for, in pixels.
 *
 * Above this width the oversampling drops below 4, which a large sample frame
 * does not need. The renderer pays for every stream pixel twice, once in the
 * decode and once in the draw into the sample canvas: at 1024 x 576 and 20
 * frames per second the draw alone took 4.4 ms per frame.
 */
const maximumCaptureWidth = 512

/**
 * How long the window has to sit on another display before the capture
 * follows it, in milliseconds.
 *
 * A capture is pinned to the display it opened on. Dragging the window across
 * the seam flips the dominant display on every frame near the midpoint, and a
 * restart costs a new getDisplayMedia call and a gap in the light, so the
 * capture waits until the window has settled on the other side.
 */
const displaySettleMs = 500

/**
 * Captures and samples the display behind the stage window for ambient lighting.
 *
 * Capture state lives in this composable. The store receives only the smoothed
 * environment. The lifecycle is:
 *
 * - `enabled` or `source` changes stop the current capture and start the next.
 * - The capture stream is constrained to a small frame at the sample rate, so
 *   the renderer never receives full-resolution frames it does not use.
 * - Each delivered frame samples once through `requestVideoFrameCallback`, so
 *   the sample rate equals the stream rate and no timer samples a stale frame.
 * - A stream that ends outside this composable disables the feature and reports
 *   the reason through diagnostics.
 */
export function useScreenAmbientLight(sources: {
  /**
   * The canvas the character renders into. Its alpha says which pixels of the
   * window AIRI paints, which is what separates the character from the desktop
   * showing through behind it. Without it the backlight stays off.
   */
  stageCanvas?: () => HTMLCanvasElement | undefined
} = {}) {
  const settings = useSettingsScreenAmbientLight()
  const {
    screenAmbientLightCaptureIntervalMs,
    screenAmbientLightEnabled,
    screenAmbientLightForcedColor,
    screenAmbientLightNeutralColorWeight,
    screenAmbientLightResponseMs,
    screenAmbientLightSampleWidth,
    screenAmbientLightSource,
  } = storeToRefs(settings)
  const ambientLight = useScreenAmbientLightEnvironment()
  const displays = useElectronAllDisplays()
  const windowBounds = useElectronWindowBounds()
  const capturedDisplay = shallowRef<(typeof displays.value)[number]>()
  const activeStream = shallowRef<MediaStream>()
  const video = document.createElement('video')
  const canvas = document.createElement('canvas')
  // The canvas exists only to read pixels back. A software canvas makes
  // getImageData cheap, and the draw into it is a downscale of a frame that is
  // already small, so the software path costs nothing measurable.
  const context = canvas.getContext('2d', { willReadFrequently: true })
  const paintedMask = useStagePaintedMask({
    stageCanvas: sources.stageCanvas,
    sampleGrid: () => ({ width: canvas.width, height: canvas.height }),
    windowSize: () => ({ width: windowBounds.width.value, height: windowBounds.height.value }),
  })
  const {
    data: diagnosticsChannelEvent,
    post: postDiagnosticsChannelEvent,
  } = useBroadcastChannel<ScreenAmbientLightDiagnosticsChannelEvent, ScreenAmbientLightDiagnosticsChannelEvent>({
    name: screenAmbientLightDiagnosticsChannelName,
  })
  let startVersion = 0
  let frameCallbackHandle = 0
  let lastSampleTime = 0
  // When the last diagnostics request stops keeping the stream alive. Nothing
  // listens most of the time, and a snapshot carries a copy of the capture
  // frame, so publishing on every sample would clone that frame for nobody.
  let diagnosticsWatchedUntil = 0
  let lastCaptureError: string | undefined
  let lastDiagnostics: ScreenAmbientLightDiagnosticsSnapshot | undefined

  video.muted = true
  video.playsInline = true

  const hasWindowBounds = computed(() => windowBounds.width.value > 0 && windowBounds.height.value > 0)
  const samplingOptions = computed(() => ({
    neutralColorWeight: screenAmbientLightNeutralColorWeight.value,
  }))
  const captureFrameRate = computed(() => clamp(1000 / Math.max(1, screenAmbientLightCaptureIntervalMs.value), 1, 30))
  const {
    selectWithSource,
    checkMacOSPermission,
    requestMacOSPermission,
  } = useElectronScreenCapture(getElectronEventaContext(), sourcesOptions)

  // The display the window mostly covers. It decides which screen the capture
  // opens, and `undefined` means the answer is not known yet: the display list
  // and the window bounds both arrive over IPC after mount.
  const dominantDisplay = computed(() => {
    if (!hasWindowBounds.value || displays.value.length === 0)
      return undefined
    return findDominantDisplayArea(currentWindowBounds(), displays.value)
  })

  watch([screenAmbientLightEnabled, screenAmbientLightSource], () => void restart(), { immediate: true })

  // A capture shows the display it opened on, with the bounds it had then.
  // A window settled elsewhere, or a display rescaled under it, makes those
  // stale, so the capture opens again. The captured display is a source too:
  // a move during start() is checked once the stream is up.
  watchDebounced([dominantDisplay, capturedDisplay], ([display, captured]) => {
    if (!display || !captured)
      return
    if (display.id === captured.id && sameBounds(display.bounds, captured.bounds))
      return
    void restart()
  }, { debounce: displaySettleMs })

  async function restart() {
    const version = ++startVersion
    stop()
    if (!screenAmbientLightEnabled.value) {
      publishDiagnostics(lastCaptureError ? 'error' : 'disabled')
      return
    }

    lastCaptureError = undefined

    if (screenAmbientLightSource.value === 'forced-color') {
      applyForcedColor()
      return
    }

    publishDiagnostics('starting')
    try {
      await start(version)
    }
    catch (error) {
      if (version !== startVersion)
        return

      lastCaptureError = errorMessageFrom(error) ?? 'Unknown error'
      console.error(`Failed to start screen ambient light: ${lastCaptureError}`)
      publishDiagnostics('error')
      screenAmbientLightEnabled.value = false
    }
  }

  watch(diagnosticsChannelEvent, (event) => {
    if (event?.type !== 'request-current')
      return

    diagnosticsWatchedUntil = performance.now() + screenAmbientLightDiagnosticsWatchMs
    if (lastDiagnostics)
      postDiagnosticsChannelEvent({ type: 'snapshot', snapshot: lastDiagnostics })
    else
      publishDiagnostics('disabled')
  })

  watch(screenAmbientLightForcedColor, () => {
    if (screenAmbientLightEnabled.value && screenAmbientLightSource.value === 'forced-color')
      applyForcedColor()
  })

  // The stream rate is the sample rate, so a new interval must reach the track.
  // A rejected constraint keeps the old rate, which is slower but still correct.
  watch([captureFrameRate, screenAmbientLightSampleWidth], async ([frameRate]) => {
    const track = activeStream.value?.getVideoTracks()[0]
    const display = capturedDisplay.value
    if (!track || !display)
      return

    try {
      await track.applyConstraints(captureConstraints(display.bounds, frameRate))
    }
    catch (error) {
      console.warn(`Failed to update the screen ambient light capture constraints: ${errorMessageFrom(error)}`)
    }
  })

  onScopeDispose(() => {
    startVersion += 1
    stop()
  })

  async function start(version: number) {
    if (!context)
      throw new Error('Failed to create the screen sampling canvas')

    // Only macOS puts screen capture behind a permission, and the main-process
    // handler throws on every other platform, which would fail the start and
    // switch the feature off. Elsewhere the capture begins straight away.
    if (window.platform === 'darwin') {
      const permission = await checkMacOSPermission()
      if (permission === 'not-determined')
        await requestMacOSPermission()
    }

    if (displays.value.length === 0)
      await until(displays).toMatch(currentDisplays => currentDisplays.length > 0)
    if (!hasWindowBounds.value)
      await until(hasWindowBounds).toBe(true)
    if (version !== startVersion)
      return

    const bounds = currentWindowBounds()
    const display = findDominantDisplayArea(bounds, displays.value)
    if (!display)
      throw new Error('No display is available for screen ambient light')

    const stream = await selectWithSource(
      (sources) => {
        const screens = sources.filter(candidate => candidate.id.startsWith('screen:'))
        // Passing an empty id on would fail later inside the main process with
        // a message that names no cause. On macOS an empty list is what a
        // missing screen-recording permission looks like from here, so that
        // platform gets the extra hint.
        if (screens.length === 0) {
          throw new Error(window.platform === 'darwin'
            ? i18n.global.t('companion-ui.errors.screen-capture', { name: i18n.global.t('companion-ui.app.name') })
            : 'No screen-capture source is available.')
        }

        const matched = screens.find(candidate => candidate.display_id === String(display.id))
        if (matched)
          return matched.id

        // A Wayland portal returns one source with no display id, so a single
        // screen is a forced choice. The display bounds used below are then a
        // guess: right on one display, while on several the portal shows
        // whichever screen the user picked, which this side cannot see.
        if (screens.length === 1)
          return screens[0].id

        // Several screens and none matching means the capture would light the
        // character from an arbitrary display while normalizing against the
        // one the window is on. Failing keeps the light off instead.
        throw new Error(`No screen-capture source matches display ${display.id}.`)
      },
      async () => await navigator.mediaDevices.getDisplayMedia({
        video: captureConstraints(display.bounds, captureFrameRate.value),
        audio: false,
      }),
    )

    if (version !== startVersion) {
      stream.getTracks().forEach(track => track.stop())
      return
    }

    capturedDisplay.value = display
    activeStream.value = stream
    stream.getVideoTracks().forEach((track) => {
      track.addEventListener('ended', () => {
        if (activeStream.value === stream) {
          lastCaptureError = 'The screen-capture stream ended.'
          screenAmbientLightEnabled.value = false
        }
      }, { once: true })
    })

    video.srcObject = stream
    await waitForVideo(video)
    if (version !== startVersion)
      return

    lastSampleTime = performance.now()
    scheduleFrameSample(version)
  }

  /**
   * Width and height are maximums in the display aspect, so Chromium scales the
   * frame down without cropping it. The frame rate matches the sample interval.
   * Both were verified against Electron 43: a request for 320x180 at 5 fps
   * delivered 320x180 frames at about 6 fps, while an unconstrained request
   * delivered the full 5120x2880 display at 30 fps.
   */
  function captureConstraints(
    display: { width: number, height: number },
    frameRate: number,
  ): MediaTrackConstraints {
    const aspect = display.width / Math.max(1, display.height)
    const width = Math.min(display.width, maximumCaptureWidth, Math.round(screenAmbientLightSampleWidth.value * captureOversampling))
    return {
      width: { max: width },
      height: { max: Math.max(1, Math.round(width / aspect)) },
      frameRate: { max: frameRate },
    }
  }

  function scheduleFrameSample(version: number) {
    frameCallbackHandle = video.requestVideoFrameCallback(() => {
      if (version !== startVersion)
        return
      sample()
      scheduleFrameSample(version)
    })
  }

  function stop() {
    if (frameCallbackHandle !== 0) {
      video.cancelVideoFrameCallback(frameCallbackHandle)
      frameCallbackHandle = 0
    }
    const stream = activeStream.value
    activeStream.value = undefined
    capturedDisplay.value = undefined
    video.pause()
    video.srcObject = null
    stream?.getTracks().forEach(track => track.stop())
    paintedMask.reset()
    ambientLight.reset()
  }

  /**
   * Sizes the sample canvas so that a frame pixel is square on screen.
   *
   * The track already delivers the display aspect, so matching it means the
   * measurement never stretches the frame. Stretching made the blur oval and
   * weighed the squashed axis more, which moved the map mean and the exposure
   * whenever a light moved between the sides and the top.
   */
  function followVideoShape() {
    const width = Math.max(1, Math.round(screenAmbientLightSampleWidth.value))
    const height = Math.max(1, Math.round(width * video.videoHeight / Math.max(1, video.videoWidth)))
    if (canvas.width === width && canvas.height === height)
      return

    canvas.width = width
    canvas.height = height
    paintedMask.reset()
  }

  function sample() {
    if (!context || video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA)
      return

    const display = capturedDisplay.value
    if (!display)
      return

    followVideoShape()
    context.drawImage(video, 0, 0, canvas.width, canvas.height)
    const frame = context.getImageData(0, 0, canvas.width, canvas.height)
    const now = performance.now()
    const excludedWindow = normalizeWindowBounds(display.bounds, currentWindowBounds())
    const painted = paintedMask.maskFor(excludedWindow, now)
    const subjectInWindow = painted?.subject ?? wholeWindowRectangle
    // The mask measures the subject inside the window; the sampler places its
    // maps on the display, so the rectangle changes frame here.
    const subjectOnDisplay = {
      x: excludedWindow.x + subjectInWindow.x * excludedWindow.width,
      y: excludedWindow.y + subjectInWindow.y * excludedWindow.height,
      width: subjectInWindow.width * excludedWindow.width,
      height: subjectInWindow.height * excludedWindow.height,
    }
    const result = sampleScreenAmbientLight(frame, {
      exclude: excludedWindow,
      subject: subjectOnDisplay,
      paintedAlpha: painted?.alpha,
    }, samplingOptions.value)

    const nextEnvironment = ambientLight.active
      ? smoothAmbientLightEnvironment(ambientLight.environment, result.environment, now - lastSampleTime, screenAmbientLightResponseMs.value)
      : result.environment
    lastSampleTime = now
    ambientLight.setEnvironment(nextEnvironment, subjectInWindow)

    // The frame is the expensive half of a snapshot, and only the devtool
    // preview reads it. Everything else is already-allocated state that costs
    // nothing to reference, so an unwatched capture still records a snapshot
    // for the next request to answer with.
    const watched = now < diagnosticsWatchedUntil
    publishDiagnostics('capturing', {
      frame: watched
        ? { width: frame.width, height: frame.height, data: frame.data.slice() }
        : undefined,
      excludedRegion: excludedWindow,
      subjectRegion: subjectOnDisplay,
      sampling: {
        ...result.diagnostics,
        targetEnvironment: result.environment,
        appliedEnvironment: nextEnvironment,
      },
    }, watched)
  }

  function applyForcedColor() {
    const sample = ambientLightSampleFromHex(screenAmbientLightForcedColor.value)
    if (!sample) {
      lastCaptureError = 'The forced color must use #RRGGBB or #RRGGBBAA format.'
      console.error(`Failed to apply forced ambient light: ${lastCaptureError}`)
      ambientLight.reset()
      publishDiagnostics('error')
      return
    }

    lastCaptureError = undefined
    const environment = uniformAmbientLightEnvironment(sample)
    ambientLight.setEnvironment(environment)
    publishDiagnostics('forced-color', {
      sampling: {
        totalPixelCount: 0,
        excludedPixelCount: 0,
        transparentPixelCount: 0,
        acceptedPixelCount: 0,
        seeThroughPixelCount: 0,
        targetEnvironment: environment,
        appliedEnvironment: environment,
      },
    })
  }

  function currentWindowBounds() {
    return {
      x: windowBounds.x.value,
      y: windowBounds.y.value,
      width: windowBounds.width.value,
      height: windowBounds.height.value,
    }
  }

  /**
   * Records a snapshot and, unless `post` says otherwise, sends it.
   *
   * A lifecycle change always sends, because a viewer has to learn that the
   * capture started, stopped, or failed. A per-frame update sends only while a
   * viewer keeps asking for one.
   */
  function publishDiagnostics(
    status: ScreenAmbientLightCaptureStatus,
    details: Partial<Pick<ScreenAmbientLightDiagnosticsSnapshot, 'frame' | 'excludedRegion' | 'subjectRegion' | 'sampling'>> = {},
    post = true,
  ) {
    const display = capturedDisplay.value
    const snapshot: ScreenAmbientLightDiagnosticsSnapshot = {
      publishedAt: Date.now(),
      status,
      source: screenAmbientLightSource.value,
      error: lastCaptureError,
      display: display
        ? {
            id: display.id,
            bounds: { ...display.bounds },
          }
        : undefined,
      windowBounds: currentWindowBounds(),
      videoSize: video.videoWidth > 0 && video.videoHeight > 0
        ? { width: video.videoWidth, height: video.videoHeight }
        : undefined,
      ...details,
    }
    lastDiagnostics = snapshot
    if (post)
      postDiagnosticsChannelEvent({ type: 'snapshot', snapshot })
  }
}

function sameBounds(a: Rectangle, b: Rectangle) {
  return a.x === b.x && a.y === b.y && a.width === b.width && a.height === b.height
}

function normalizeWindowBounds(
  display: { x: number, y: number, width: number, height: number },
  window: { x: number, y: number, width: number, height: number },
) {
  return {
    x: (window.x - display.x) / display.width,
    y: (window.y - display.y) / display.height,
    width: window.width / display.width,
    height: window.height / display.height,
  }
}

async function waitForVideo(video: HTMLVideoElement) {
  if (video.readyState < HTMLMediaElement.HAVE_METADATA) {
    await new Promise<void>((resolve, reject) => {
      video.addEventListener('loadedmetadata', () => resolve(), { once: true })
      video.addEventListener('error', () => reject(video.error ?? new Error('Screen capture video failed to load')), { once: true })
    })
  }

  await video.play()
}
