<script setup lang="ts">
import type { ChatFloatingState } from '../../shared/eventa'

import { getElectronEventaContext, useElectronEventaInvoke, useElectronMouseInElement } from '@proj-airi/electron-vueuse'
import { ChatSessionsDrawer } from '@proj-airi/stage-ui/components'
import { useAiriCardStore } from '@proj-airi/stage-ui/stores/modules/airi-card'
import { useEventListener, useLocalStorage } from '@vueuse/core'
import { storeToRefs } from 'pinia'
import { computed, onMounted, onScopeDispose, shallowRef, useTemplateRef, watch } from 'vue'
import { useI18n } from 'vue-i18n'

import ChatDanmakuFeedMenu from '../components/chat-window/chat-danmaku-feed-menu.vue'
import ChatSpeechMuteButton from '../components/chat-window/chat-speech-mute-button.vue'
import ChatWindowStyleMenu from '../components/chat-window/chat-window-style-menu.vue'
import InteractiveArea from '../components/InteractiveArea.vue'

import {
  electronChatFloatingContentHidden,
  electronChatFloatingFold,
  electronChatFloatingGetState,
  electronChatFloatingMoveTo,
  electronChatFloatingResizeBy,
  electronChatFloatingStateChanged,
} from '../../shared/eventa'
import { useChatDraftHandover } from '../composables/use-chat-draft-handover'
import { dismissOverlays, useChatFloatingClickThrough } from '../composables/use-chat-floating-click-through'
import { useDanmakuFeedExpiry } from '../composables/use-danmaku-feed-expiry'
import { useWindowBackdrop } from '../composables/use-window-backdrop'
import { useControlsIslandStore } from '../stores/controls-island'

const backdropRoot = useTemplateRef<HTMLElement>('backdrop-root')
useWindowBackdrop(backdropRoot, 'panel')

const { activeCard } = storeToRefs(useAiriCardStore())
const sessionsDrawerOpen = shallowRef(false)
const interactiveArea = useTemplateRef<InstanceType<typeof InteractiveArea>>('interactive-area')
const { t } = useI18n()

// Folded until the main process answers, so the first unfold plays the same
// animation as every later one.
const state = shallowRef<ChatFloatingState>({ placement: 'attached', side: 'left', folded: true, relocating: false, pinned: false })
const getState = useElectronEventaInvoke(electronChatFloatingGetState)
const reportContentHidden = useElectronEventaInvoke(electronChatFloatingContentHidden)
const resizeBy = useElectronEventaInvoke(electronChatFloatingResizeBy)
const moveTo = useElectronEventaInvoke(electronChatFloatingMoveTo)
const foldChat = useElectronEventaInvoke(electronChatFloatingFold)

// The main process can emit before this page mounts, so the first state comes
// from the invoke and later ones from the event.
const stopStateChanged = getElectronEventaContext().on(electronChatFloatingStateChanged, (event) => {
  if (event?.body)
    state.value = event.body
})
onScopeDispose(stopStateChanged)
onMounted(async () => {
  state.value = await getState()
})

useChatDraftHandover(interactiveArea)

// `free` and `danmaku` both stay where the user drags them.
const freePlacement = computed(() => state.value.placement !== 'attached')
const danmaku = computed(() => state.value.placement === 'danmaku')
// The danmaku feed starts with its composer folded, because it is mostly read.
const composerFolded = useLocalStorage('chat-window/danmaku/composer-folded', true)
// Fade on hover, which the main window's controls island switches, turns the
// folded danmaku feed passive: the history only follows new messages, and it
// fades out and passes clicks through under the cursor. The header and the
// composer tab stay in control, and an unfolded composer pauses all of this.
const { fadeOnHoverEnabled } = storeToRefs(useControlsIslandStore())
const passiveFeed = computed(() => danmaku.value && fadeOnHoverEnabled.value && composerFolded.value)
// The cursor comes from the main process, because a click-through window
// gets no mouse events.
const { isOutside: cursorOutsideHistory } = useElectronMouseInElement(computed(() => interactiveArea.value?.historyLayer))
// The folded danmaku feed hides read messages. They come back while the
// cursor is over the feed, like notifications, and while the composer is
// unfolded, so the history stays in reach. A passive feed fades out under
// the cursor instead, so there the cursor does not bring them back.
const expireMessages = computed(() => composerFolded.value && (passiveFeed.value || cursorOutsideHistory.value))
const expiredBefore = useDanmakuFeedExpiry(danmaku, expireMessages)
const { hitTest } = useChatFloatingClickThrough({
  pinned: () => state.value.pinned,
  passiveArea: () => passiveFeed.value ? interactiveArea.value?.historyLayer : undefined,
})
// The content stays mounted while it is hidden, so a fold or a move to the
// other side keeps the unsent draft, attachments and reply target.
const contentShown = computed(() => !state.value.folded && !state.value.relocating)
// Menus and dialogs close as the content hides, so they neither stay on
// screen during the fold nor come back with the next unfold.
watch(contentShown, (shown) => {
  if (!shown)
    void dismissOverlays()
})

// The character stands on the other side of the chat: the chat folds toward
// it, and the resize grip sits away from it.
const characterOnLeft = computed(() => state.value.side === 'right')

interface WindowDelta {
  deltaX: number
  deltaY: number
}

/**
 * A press on the resize grip or the drag handle, in screen pixels, which stay
 * valid while the window moves under the pointer. Pointer capture sends the
 * moves to the pressed element even when the window lags behind the pointer.
 */
interface HeldPointer {
  /** The pressed grip or handle, which holds the pointer capture. */
  element: HTMLElement
  pointerId: number
  pressX: number
  pressY: number
  /** Window position when the press started. */
  windowX: number
  windowY: number
  /** Pointer movement already sent as resize steps. */
  resizedX: number
  resizedY: number
}

/** `undefined` when neither the grip nor the handle is held. */
let heldPointer: HeldPointer | undefined

function holdPointer(event: PointerEvent) {
  const element = event.currentTarget as HTMLElement
  element.setPointerCapture(event.pointerId)
  heldPointer = {
    element,
    pointerId: event.pointerId,
    pressX: event.screenX,
    pressY: event.screenY,
    windowX: window.screenX,
    windowY: window.screenY,
    resizedX: 0,
    resizedY: 0,
  }
}

/** Sends the pointer movement since the last step to the main process, which resizes the window. */
function resizeWithHeldPointer(event: PointerEvent) {
  const held = pointerStillHeld(event)
  if (!held)
    return

  // Whole pixels only; the rounding remainder carries into the next step.
  const deltaX = Math.round(event.screenX - held.pressX) - held.resizedX
  const deltaY = Math.round(event.screenY - held.pressY) - held.resizedY
  if (deltaX === 0 && deltaY === 0)
    return

  held.resizedX += deltaX
  held.resizedY += deltaY
  void resizeBy({ deltaX, deltaY })
}

/**
 * Asks for the window position that the pointer movement since the press
 * gives. It is measured from the press, not from the window: a screen edge
 * can stop the window, and a drag that goes on must still reach the next
 * display.
 */
function moveWithHeldPointer(event: PointerEvent) {
  const held = pointerStillHeld(event)
  if (!held)
    return

  void moveTo({
    x: Math.round(held.windowX + event.screenX - held.pressX),
    y: Math.round(held.windowY + event.screenY - held.pressY),
  })
}

// Capture ends on release, cancel or removal of the element alike. A hold
// that ends without them gives the capture back here.
function releasePointer() {
  if (heldPointer?.element.hasPointerCapture(heldPointer.pointerId))
    heldPointer.element.releasePointerCapture(heldPointer.pointerId)
  heldPointer = undefined
}

/**
 * The held press, or `undefined` once the buttons are up.
 *
 * A release can miss this window, for example while another window takes the
 * pointer. The grip would then stay held, and the mouse moves that reach this
 * window while the main window is dragged would resize the chat. A move with
 * no button down ends the hold instead.
 */
function pointerStillHeld(event: PointerEvent) {
  if (heldPointer && event.buttons === 0)
    releasePointer()
  return heldPointer
}

// A window that loses focus has no press left in it.
useEventListener(window, 'blur', releasePointer)

/** Keyboard step for the resize grip and the drag handle, in screen pixels. */
const keyboardStep = 16

/** Moves or resizes the window from the arrow keys, as a pointer drag would. */
function handleArrowKey(event: KeyboardEvent, applyDelta: (delta: WindowDelta) => unknown) {
  const step = event.shiftKey ? keyboardStep * 4 : keyboardStep
  const deltas: Record<string, WindowDelta> = {
    ArrowLeft: { deltaX: -step, deltaY: 0 },
    ArrowRight: { deltaX: step, deltaY: 0 },
    ArrowUp: { deltaX: 0, deltaY: -step },
    ArrowDown: { deltaX: 0, deltaY: step },
  }
  const delta = deltas[event.key]
  if (!delta)
    return

  event.preventDefault()
  void applyDelta(delta)
}

function moveByKeyboard(delta: WindowDelta) {
  return moveTo({ x: window.screenX + delta.deltaX, y: window.screenY + delta.deltaY })
}
</script>

<template>
  <div
    :class="['relative h-full w-full']"
  >
    <Transition
      :name="characterOnLeft ? 'chat-floating-fold-left' : 'chat-floating-fold-right'"
      @after-enter="hitTest()"
      @after-leave="reportContentHidden()"
    >
      <div
        v-show="contentShown"
        ref="backdrop-root"
        data-window-backdrop-surface
        data-window-backdrop-floating-background
        :class="['absolute inset-0 flex flex-col gap-1 rounded-3xl pt-3']"
      >
        <div :class="['flex items-center gap-2 px-4', characterOnLeft ? 'flex-row-reverse' : '']">
          <div
            :class="[
              'shrink-0 rounded-full p-0.5 shadow-md',
              'bg-white ring-1 ring-neutral-200 dark:bg-neutral-900 dark:ring-neutral-800',
            ]"
          >
            <button
              :title="t('tamagotchi.stage.chat-window.resize')"
              :aria-label="t('tamagotchi.stage.chat-window.resize')"
              :class="[
                'size-8 touch-none rounded-full',
                'flex items-center justify-center outline-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-300 transition-colors text-neutral-400 hover:bg-neutral-200 hover:text-primary-500 dark:text-neutral-500 dark:hover:bg-neutral-800 dark:hover:text-primary-400',
                characterOnLeft ? 'cursor-nesw-resize' : 'cursor-nwse-resize',
              ]"
              @pointerdown="holdPointer"
              @pointermove="resizeWithHeldPointer"
              @lostpointercapture="releasePointer"
              @keydown="handleArrowKey($event, resizeBy)"
            >
              <!-- The two-headed arrow matches the resize cursor of the grip corner. -->
              <div :class="[characterOnLeft ? 'i-lucide:move-diagonal' : 'i-lucide:move-diagonal-2', 'size-4']" />
            </button>
          </div>

          <div
            :class="[
              'min-w-0 flex items-center gap-1 rounded-full p-1 shadow-md',
              'bg-white ring-1 ring-neutral-200 dark:bg-neutral-900 dark:ring-neutral-800',
            ]"
          >
            <button
              v-if="freePlacement"
              :title="t('tamagotchi.stage.chat-window.move')"
              :aria-label="t('tamagotchi.stage.chat-window.move')"
              :class="['h-7 w-5 shrink-0 cursor-grab touch-none rounded-full', 'flex items-center justify-center outline-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-300 transition-colors text-neutral-400 hover:bg-neutral-200 hover:text-primary-500 dark:text-neutral-500 dark:hover:bg-neutral-800 dark:hover:text-primary-400']"
              @pointerdown="holdPointer"
              @pointermove="moveWithHeldPointer"
              @lostpointercapture="releasePointer"
              @keydown="handleArrowKey($event, moveByKeyboard)"
            >
              <div class="i-ph:dots-six-vertical-bold size-4" />
            </button>
            <!-- A plain button: GhostButton wraps its slot in a span that cannot shrink, so a long name could not truncate. -->
            <button
              :class="[
                'min-w-0 flex items-center gap-2 rounded-full px-2 py-0.5 outline-none transition-colors',
                'focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-300',
                'text-neutral-700 hover:bg-primary-500/10 hover:text-primary-700 dark:text-neutral-200 dark:hover:bg-primary-400/10 dark:hover:text-primary-300',
              ]"
              @click="sessionsDrawerOpen = true"
            >
              <div class="i-solar:chat-line-bold shrink-0 text-neutral-400 dark:text-neutral-500" />
              <span class="truncate text-sm font-medium">{{ activeCard?.name || t('companion-ui.app.name') }}</span>
            </button>
            <ChatSpeechMuteButton :class="['shrink-0 rounded-full!']" />
            <ChatDanmakuFeedMenu v-if="danmaku" :class="['shrink-0 rounded-full!']" />
            <ChatWindowStyleMenu :class="['shrink-0 rounded-full!']" />
          </div>

          <div
            :class="[
              'shrink-0 rounded-full p-0.5 shadow-md',
              'bg-white ring-1 ring-neutral-200 dark:bg-neutral-900 dark:ring-neutral-800',
            ]"
          >
            <button
              :title="t('tamagotchi.stage.chat-window.fold')"
              :aria-label="t('tamagotchi.stage.chat-window.fold')"
              :class="['size-8 rounded-full', 'flex items-center justify-center outline-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-300 transition-colors text-neutral-400 hover:bg-neutral-200 hover:text-primary-500 dark:text-neutral-500 dark:hover:bg-neutral-800 dark:hover:text-primary-400']"
              @click="foldChat()"
            >
              <div class="i-lucide:minimize-2 size-4" />
            </button>
          </div>
        </div>

        <div :class="['relative min-h-0 flex-1']">
          <InteractiveArea
            ref="interactive-area"
            v-model:composer-folded="composerFolded"
            floating
            :composer-foldable="danmaku"
            :passive="passiveFeed"
            :expired-before="expiredBefore"
          />
        </div>
      </div>
    </Transition>
    <ChatSessionsDrawer v-model="sessionsDrawerOpen" />
  </div>
</template>

<style scoped>
/*
 * The chat folds into the bottom corner beside the character: bottom-right
 * when the chat is on the left of the character, bottom-left when it is on
 * the right.
 */
.chat-floating-fold-right-enter-active,
.chat-floating-fold-right-leave-active,
.chat-floating-fold-left-enter-active,
.chat-floating-fold-left-leave-active {
  transition:
    clip-path 380ms cubic-bezier(0.2, 0.8, 0.2, 1),
    transform 380ms cubic-bezier(0.2, 0.8, 0.2, 1),
    opacity 380ms ease;
}

.chat-floating-fold-right-enter-active,
.chat-floating-fold-right-leave-active {
  transform-origin: bottom right;
}

.chat-floating-fold-left-enter-active,
.chat-floating-fold-left-leave-active {
  transform-origin: bottom left;
}

.chat-floating-fold-right-enter-from,
.chat-floating-fold-right-leave-to {
  clip-path: inset(100% 0 0 100% round 24px);
  transform: scale(0.94);
  opacity: 0;
}

.chat-floating-fold-left-enter-from,
.chat-floating-fold-left-leave-to {
  clip-path: inset(100% 100% 0 0 round 24px);
  transform: scale(0.94);
  opacity: 0;
}

.chat-floating-fold-right-enter-to,
.chat-floating-fold-right-leave-from,
.chat-floating-fold-left-enter-to,
.chat-floating-fold-left-leave-from {
  clip-path: inset(0 0 0 0 round 24px);
}

@media (prefers-reduced-motion: reduce) {
  .chat-floating-fold-right-enter-active,
  .chat-floating-fold-right-leave-active,
  .chat-floating-fold-left-enter-active,
  .chat-floating-fold-left-leave-active {
    transition: none;
  }
}
</style>

<route lang="yaml">
meta:
  layout: stage
</route>
