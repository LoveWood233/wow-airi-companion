<script setup lang="ts">
import { useElectronEventaInvoke } from '@proj-airi/electron-vueuse'
import { OnboardingScreen } from '@proj-airi/stage-ui/components'
import { useOnboardingStore } from '@proj-airi/stage-ui/stores/onboarding'
import { useTheme } from '@proj-airi/ui'
import { computed } from 'vue'

import { electronOnboardingClose } from '../../shared/eventa'

const onboardingStore = useOnboardingStore()
const { isDark } = useTheme()
const closeWindow = useElectronEventaInvoke(electronOnboardingClose)

const bgClass = computed(() => isDark.value ? 'bg-[#0f0f0f]' : 'bg-white')

async function handleSkipped() {
  await onboardingStore.markSetupSkipped()
  await closeWindow()
}

async function handleConfigured() {
  await onboardingStore.markSetupCompleted()
  await closeWindow()
}
</script>

<template>
  <!-- Same flex/min-h-0 chain as OnboardingDialog so model step grid scrolls inside the viewport (not the whole page). -->
  <div
    :class="['onboarding-root h-full min-h-0 w-full', 'flex flex-col overflow-hidden overscroll-none', bgClass]"
  >
    <div :class="['min-h-8 w-full flex-shrink-0 select-none drag-region', bgClass]" />
    <div :class="['mx-8 mb-8 mt-2', 'min-h-0 flex flex-1 flex-col']">
      <OnboardingScreen @skipped="handleSkipped" @configured="handleConfigured" />
    </div>
  </div>
</template>

<style scoped>
.onboarding-root {
  scrollbar-width: none;
}

.onboarding-root::-webkit-scrollbar {
  display: none;
}
</style>

<route lang="yaml">
meta:
  layout: plain
</route>
