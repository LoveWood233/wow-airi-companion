<script setup lang="ts">
import type { AboutBuildInfo, AboutLink } from './types'

import { computed } from 'vue'
import { useI18n } from 'vue-i18n'

const props = withDefaults(defineProps<{
  title?: string
  highlight?: string
  subtitle?: string
  buildInfo?: AboutBuildInfo
  links?: AboutLink[]
}>(), {
  title: '',
  highlight: '',
  subtitle: '',
  links: () => ([
    { label: 'GitHub', href: 'https://github.com/LoveWood233/wow-airi-companion', icon: 'i-simple-icons:github' },
  ]),
})

const { t } = useI18n()

const hasBuildInfo = computed(() => {
  const info = props.buildInfo
  if (!info)
    return false

  return Boolean(info.branch || info.commit || info.builtOn || info.version)
})
</script>

<template>
  <div :class="['max-w-[min(960px,calc(100%-2rem))]', 'mx-auto', 'h-full', 'flex', 'flex-col', 'pt-14']">
    <div class="mb-14 text-center font-sans-rounded">
      <div class="text-5xl">
        <span class="text-neutral-400 dark:text-neutral-100/65">{{ title }}</span>
        <span class="text-pink-400 dark:text-pink-300/90">&nbsp;{{ highlight || t('companion-ui.app.name') }}</span>
      </div>
      <div v-if="subtitle" class="mt-2 text-base text-neutral-500 dark:text-neutral-400">
        {{ subtitle }}
      </div>
    </div>

    <slot name="before-build-info" />

    <div v-if="hasBuildInfo" :class="['flex-1']">
      <div :class="['text-neutral-500 dark:text-neutral-400']">
        {{ t('companion-ui.about.build-info') }}
      </div>
      <div :class="['mt-4', 'grid grid-cols-[120px_1fr]', 'gap-2', 'text-sm']">
        <template v-if="buildInfo?.version">
          <div :class="['text-neutral-500 dark:text-neutral-400']">
            {{ t('companion-ui.about.version') }}
          </div>
          <div :class="['font-mono']">
            {{ buildInfo.version }}
          </div>
        </template>
        <template v-if="buildInfo?.branch">
          <div :class="['text-neutral-500 dark:text-neutral-400']">
            {{ t('companion-ui.about.branch') }}
          </div>
          <div :class="['font-mono']">
            {{ buildInfo.branch }}
          </div>
        </template>
        <template v-if="buildInfo?.commit">
          <div :class="['text-neutral-500 dark:text-neutral-400']">
            {{ t('companion-ui.about.commit') }}
          </div>
          <div :class="['font-mono']">
            {{ buildInfo.commit }}
          </div>
        </template>
        <template v-if="buildInfo?.builtOn">
          <div :class="['text-neutral-500 dark:text-neutral-400']">
            {{ t('companion-ui.about.built-on') }}
          </div>
          <div :class="['font-mono']">
            {{ buildInfo.builtOn }}
          </div>
        </template>
      </div>
    </div>

    <slot name="after-build-info" />

    <div :class="['my-10']">
      <div :class="['text-neutral-500 dark:text-neutral-400']">
        {{ t('companion-ui.about.about') }}
      </div>
      <div :class="['mt-4 flex flex-col gap-2']">
        <a
          v-for="link in links"
          :key="link.href"
          :class="[
            'block',
            'flex items-center gap-2',
            'rounded-xl',
            'px-3 py-2',
            'lg:px-5 lg:py-3',
            'outline-none',
            'backdrop-blur-md',
            'active:scale-98',
            'focus:outline-none',
            'text-nowrap',
            'text-sm md:text-base',
            'text-slate-700 dark:text-slate-100',
            'bg-black/4',
            'transition-colors transition-transform duration-200 ease-in-out',
            'hover:bg-black/6',
            'dark:bg-black/10 dark:hover:bg-white/20',
          ]"
          :href="link.href"
          target="_blank"
        >
          <div :class="link.icon" />
          <div>{{ link.label }}</div>
        </a>
      </div>
    </div>
  </div>
</template>
