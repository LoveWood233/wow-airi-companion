import type { Session, User } from 'better-auth'

import { isGenerationProvider } from '@proj-airi/provider-inference'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { nextTick } from 'vue'

import { OFFICIAL_SPEECH_PROVIDER_ID, OFFICIAL_SPEECH_STREAMING_PROVIDER_ID, OFFICIAL_TRANSCRIPTION_PROVIDER_ID } from '../../libs/providers/providers/official'
import { inferenceServiceProvidersService } from '../../services/inference-service-providers'
import { useAuthStore } from '../auth'
import { useProviderConfigStore } from './config'
import { useProviderStore } from './provider'

const mocks = vi.hoisted(() => ({
  updateCredits: vi.fn(async () => Response.json({ flux: 0 })),
}))

vi.mock('../../composables/api', () => ({
  client: {
    api: {
      v1: {
        flux: { $get: mocks.updateCredits },
      },
    },
  },
}))

vi.mock('vue-i18n', () => ({
  useI18n: () => ({
    t: (_key: string, fallback?: string) => fallback ?? _key,
  }),
}))

/** Creates stable authenticated state for provider-store tests. */
function createAuthenticatedState(): { session: Session, token: string, user: User } {
  const user: User = {
    id: 'user-1',
    name: 'AIRI User',
    email: 'user@example.com',
    emailVerified: true,
    createdAt: new Date('2026-01-01T00:00:00.000Z'),
    updatedAt: new Date('2026-01-01T00:00:00.000Z'),
  }
  const session: Session = {
    id: 'session-1',
    token: 'server-session-token',
    userId: user.id,
    expiresAt: new Date('2026-12-01T00:00:00.000Z'),
    createdAt: new Date('2026-01-01T00:00:00.000Z'),
    updatedAt: new Date('2026-01-01T00:00:00.000Z'),
  }
  return { session, token: 'restored-access-token', user }
}

function stubOpenAiReplica(config: Record<string, unknown>) {
  const listRemote = vi.spyOn(inferenceServiceProvidersService, 'listRemote').mockResolvedValue([{
    id: 'openai',
    definitionId: 'openai',
    config,
    updatedAt: '2026-01-02T00:00:00.000Z',
    deletedAt: null,
  }])
  const upsertRemote = vi.spyOn(inferenceServiceProvidersService, 'upsertRemote').mockImplementation(async (_client, provider) => ({
    id: provider.id,
    definitionId: provider.definitionId,
    config: provider.config,
    updatedAt: '2026-01-02T00:00:00.000Z',
    deletedAt: null,
  }))
  const deleteRemote = vi.spyOn(inferenceServiceProvidersService, 'deleteRemote').mockResolvedValue()
  useAuthStore().$patch(createAuthenticatedState())
  return () => {
    listRemote.mockRestore()
    upsertRemote.mockRestore()
    deleteRemote.mockRestore()
  }
}

describe('provider store synchronization boundary', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    mocks.updateCredits.mockClear()
  })

  // ROOT CAUSE:
  //
  // Provider actions, serializable runtime data, and computedAsync output
  // shared one synced store. Applying the derived ref in every Electron
  // renderer restarted its local async computation, which proposed another
  // snapshot and starved the main window's event loop.
  //
  // We fixed this by keeping executable actions in the provider store and
  // placing the replicated data in an internal state-only store.
  it('keeps replicated runtime data out of the executable provider store state', () => {
    const store = useProviderStore()
    const runtimeState = {
      models: [],
      defaultModel: null,
      modelStatus: 'ready' as const,
      modelError: null,
    }

    store.providerRuntimeState.openai = runtimeState

    expect(store.$state).not.toHaveProperty('providerRuntimeState')
    expect(store.$state).not.toHaveProperty('providerAvailabilityOverrides')
    expect(store.providerRuntimeState.openai).toEqual(runtimeState)
  })

  // ROOT CAUSE:
  //
  // The provider store installed immediate watchers that called synchronized
  // background actions. Every renderer created the same watchers, so one
  // shared state transition produced one routed action per renderer.
  //
  // We fixed this by keeping background work behind explicit action calls.
  it('does not start background provider actions when shared configuration changes', async () => {
    const store = useProviderStore()
    const configStore = useProviderConfigStore()

    await nextTick()
    await new Promise<void>(resolve => queueMicrotask(resolve))

    const refreshValidation = vi.spyOn(store, 'refreshListedProviderValidation').mockResolvedValue()
    const refreshModels = vi.spyOn(store, 'refreshModelsForChangedCredentials').mockResolvedValue()

    configStore.ensureProvider('openai', 'openai', { apiKey: 'test-key' })
    await nextTick()
    await new Promise<void>(resolve => queueMicrotask(resolve))

    expect(refreshValidation).not.toHaveBeenCalled()
    expect(refreshModels).not.toHaveBeenCalled()
  })

  // ROOT CAUSE:
  //
  // Provider metadata projection called the config store's `getProvider`
  // action once for every registered provider. Pinia tracing and plugins then
  // processed hundreds of action lifecycle events during renderer startup,
  // even though each call was only a read.
  // Internal provider projections now read the reactive provider map directly.
  it('does not dispatch config actions while projecting provider metadata', async () => {
    const configStore = useProviderConfigStore()
    let getProviderCalls = 0
    configStore.$onAction(({ name }) => {
      if (name === 'getProvider')
        getProviderCalls += 1
    })

    useProviderStore()
    await nextTick()

    expect(getProviderCalls).toBe(0)
  })

  // ROOT CAUSE:
  //
  // Speech settings pages wrote defaults into the computed `configs` map before
  // provider initialization. The derived entry made `initializeProvider` skip
  // the source provider record, so later input was not persisted.
  //
  // The provider record is now the only existence check. A derived entry cannot
  // prevent initialization of the persisted source state.
  // https://github.com/moeru-ai/airi/issues/2449
  it('creates the provider when only a derived configuration entry exists (Issue #2449)', async () => {
    const store = useProviderStore()
    const configStore = useProviderConfigStore()

    configStore.configs['openai-compatible-audio-speech'] = { model: 'qwen' }

    expect(configStore.getProvider('openai-compatible-audio-speech')).toBeUndefined()

    await store.initializeProvider('openai-compatible-audio-speech')

    expect(configStore.getProvider('openai-compatible-audio-speech')).toMatchObject({
      id: 'openai-compatible-audio-speech',
      definitionId: 'openai-compatible-audio-speech',
    })
  })

  it('uses the current interface language when Sherpaw is first configured', async () => {
    let storedLanguage = 'en'
    vi.stubGlobal('localStorage', { getItem: () => storedLanguage })

    try {
      const store = useProviderStore()
      const configStore = useProviderConfigStore()

      await store.initializeProvider('speech-noop')
      storedLanguage = 'zh-Hans'
      await store.initializeProvider('sherpaw-transcription')

      expect(configStore.getProviderConfig('sherpaw-transcription')).toMatchObject({
        model: 'paraformer-zh-en',
        modelLanguageFilter: 'zh',
      })
    }
    finally {
      vi.unstubAllGlobals()
    }
  })

  // ROOT CAUSE:
  //
  // Module pages treated every credential-free provider as available before
  // configuration. The official providers also have credential-free local
  // definitions, but their availability belongs to the authenticated session.
  //
  // We fixed this by requiring a configured record for official providers
  // while keeping account-free browser and local providers available.
  it('lists official providers only after authenticated setup configures them', async () => {
    const store = useProviderStore()
    const configStore = useProviderConfigStore()

    await vi.waitFor(() => {
      expect(store.moduleSpeechProvidersMetadata.map(provider => provider.id)).toContain('speech-noop')
      expect(store.moduleChatProvidersMetadata.map(provider => provider.id)).not.toContain('official-provider')
      expect(store.moduleSpeechProvidersMetadata.map(provider => provider.id)).not.toContain(OFFICIAL_SPEECH_PROVIDER_ID)
      expect(store.moduleSpeechProvidersMetadata.map(provider => provider.id)).not.toContain(OFFICIAL_SPEECH_STREAMING_PROVIDER_ID)
      expect(store.moduleTranscriptionProvidersMetadata.map(provider => provider.id)).not.toContain(OFFICIAL_TRANSCRIPTION_PROVIDER_ID)
      expect(store.moduleVisionProvidersMetadata.map(provider => provider.id)).not.toContain('vision-official-provider')
    })

    expect(configStore.providers['official-provider']).toBeUndefined()
    expect(configStore.providers[OFFICIAL_SPEECH_PROVIDER_ID]).toBeUndefined()
    expect(configStore.providers[OFFICIAL_TRANSCRIPTION_PROVIDER_ID]).toBeUndefined()
    expect(configStore.providers['vision-official-provider']).toBeUndefined()

    await store.initializeProvider('official-provider')
    await store.forceProviderConfigured('official-provider')
    await store.initializeProvider(OFFICIAL_SPEECH_PROVIDER_ID)
    await store.forceProviderConfigured(OFFICIAL_SPEECH_PROVIDER_ID)
    await store.initializeProvider(OFFICIAL_TRANSCRIPTION_PROVIDER_ID)
    await store.forceProviderConfigured(OFFICIAL_TRANSCRIPTION_PROVIDER_ID)
    await store.initializeProvider('vision-official-provider')
    await store.forceProviderConfigured('vision-official-provider')

    expect(store.moduleChatProvidersMetadata.map(provider => provider.id)).not.toContain('official-provider')
    expect(store.moduleSpeechProvidersMetadata.map(provider => provider.id)).not.toContain(OFFICIAL_SPEECH_PROVIDER_ID)
    expect(store.moduleTranscriptionProvidersMetadata.map(provider => provider.id)).not.toContain(OFFICIAL_TRANSCRIPTION_PROVIDER_ID)
    expect(store.moduleVisionProvidersMetadata.map(provider => provider.id)).not.toContain('vision-official-provider')

    useAuthStore().$patch(createAuthenticatedState())

    expect(store.moduleChatProvidersMetadata.map(provider => provider.id)).toContain('official-provider')
    expect(store.moduleSpeechProvidersMetadata.map(provider => provider.id)).toContain(OFFICIAL_SPEECH_PROVIDER_ID)
    expect(store.moduleSpeechProvidersMetadata.map(provider => provider.id)).not.toContain(OFFICIAL_SPEECH_STREAMING_PROVIDER_ID)
    expect(store.moduleTranscriptionProvidersMetadata.map(provider => provider.id)).toContain(OFFICIAL_TRANSCRIPTION_PROVIDER_ID)
    expect(store.moduleVisionProvidersMetadata.map(provider => provider.id)).toContain('vision-official-provider')
  })

  // ROOT CAUSE:
  //
  // getModelsForProvider created a new empty array for every cache miss.
  // Reactive consumers observed a false list change after each synced patch.
  //
  // We fixed this by returning one frozen fallback until a catalog exists.
  it('reuses the empty model-list fallback', () => {
    const store = useProviderStore()

    const first = store.getModelsForProvider('missing-provider')
    const second = store.getModelsForProvider('missing-provider')

    expect(second).toBe(first)
    expect(second).toEqual([])
  })

  it('applies provider-owned reasoning options without changing the cached provider', async () => {
    const store = useProviderStore()
    const configStore = useProviderConfigStore()
    configStore.ensureProvider('openai', 'openai', {
      apiKey: 'test-key',
      baseUrl: 'https://api.openai.com/v1/',
    })

    const baseProvider = await store.getProviderInstance('openai')
    const reasoningDisabledProvider = await store.getChatProviderInstance('openai', { reasoning: 'disabled' })
    const reasoningEnabledProvider = await store.getChatProviderInstance('openai', { reasoning: 'enabled' })

    expect(reasoningDisabledProvider).not.toBe(baseProvider)
    expect(reasoningEnabledProvider).not.toBe(baseProvider)
    // Use a catalog model that supports both efforts; unknown models omit reasoning fields.
    expect(reasoningDisabledProvider.generation('gpt-5.1').config).toMatchObject({ reasoning: { effort: 'none' } })
    expect(reasoningEnabledProvider.generation('gpt-5.1').config).toMatchObject({ reasoning: { effort: 'medium', summary: 'auto' } })
    expect(reasoningDisabledProvider.generation('any-model').config).not.toHaveProperty('reasoning')
    expect(reasoningEnabledProvider.generation('any-model').config).not.toHaveProperty('reasoning')
    if (!isGenerationProvider(baseProvider))
      throw new Error('Expected generation provider')
    expect(baseProvider.generation('gpt-5.1').config).not.toHaveProperty('reasoning')
  })

  // https://github.com/moeru-ai/airi/pull/2471#discussion_r3948440504
  it('drops a cached provider instance only when replica credentials change', async () => {
    // ROOT CAUSE:
    //
    // Login merge replaced the persisted OpenAI key and left providerInstanceCache
    // holding a client built from the previous key. Later chat returned that
    // client until reload.
    const network = vi.spyOn(globalThis, 'fetch').mockImplementation(async (input) => {
      const url = String(input instanceof Request ? input.url : input)
      if (url.includes('/chat/completions')) {
        return Response.json({
          id: 'chatcmpl-test',
          object: 'chat.completion',
          created: 0,
          model: 'gpt-4o-mini',
          choices: [{ index: 0, message: { role: 'assistant', content: 'pong' }, finish_reason: 'stop' }],
          usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
        })
      }
      return Response.json({ object: 'list', data: [{ id: 'gpt-4o-mini' }] })
    })
    const store = useProviderStore()
    const configStore = useProviderConfigStore()
    const openaiConfig = {
      apiKey: 'sk-old',
      baseUrl: 'https://api.openai.com/v1/',
    }
    configStore.ensureProvider('openai', 'openai', openaiConfig)
    const first = await store.getProviderInstance('openai')
    let restore = stubOpenAiReplica({ ...openaiConfig })

    try {
      await configStore.syncProviders()
      expect(await store.getProviderInstance('openai')).toBe(first)

      restore()
      restore = stubOpenAiReplica({
        apiKey: 'sk-new',
        baseUrl: 'https://api.openai.com/v1/',
      })
      await configStore.syncProviders()

      const second = await store.getProviderInstance('openai')
      expect(second).not.toBe(first)
      expect(configStore.providers.openai?.config).toEqual({
        apiKey: 'sk-new',
        baseUrl: 'https://api.openai.com/v1/',
      })
      expect(network).toHaveBeenCalled()
    }
    finally {
      restore()
      network.mockRestore()
    }
  })

  // https://github.com/moeru-ai/airi/pull/2471#discussion_r3999470560
  it('drops a cached instance when replicated credentials change without a local sync', async () => {
    // ROOT CAUSE:
    //
    // onAfterSync ran only inside the leader-routed syncProviders action.
    // The chat window is follower-only. It received the new key in the
    // replicated snapshot and kept the old client in providerInstanceCache.
    //
    // Each renderer now watches replicated credentials and drops its own cache.
    const store = useProviderStore()
    const configStore = useProviderConfigStore()
    configStore.ensureProvider('openai', 'openai', {
      apiKey: 'sk-old',
      baseUrl: 'https://api.openai.com/v1/',
    })
    const first = await store.getProviderInstance('openai')

    configStore.providers.openai = {
      ...configStore.providers.openai!,
      config: {
        apiKey: 'sk-new',
        baseUrl: 'https://api.openai.com/v1/',
      },
    }

    const second = await store.getProviderInstance('openai')
    expect(second).not.toBe(first)
  })

  // https://github.com/moeru-ai/airi/pull/2471#discussion_r3999454891
  it('adopts a remote addProvider instance on a fresh device', async () => {
    // ROOT CAUSE:
    //
    // onRemoteWorking validated row.id. addProvider ids are nanoids, so a
    // fresh device threw and merge skipped the row (broken × none).
    //
    // The working check now uses row.definitionId.
    const configStore = useProviderConfigStore()
    useProviderStore()
    const instanceId = 'added-speech-1'
    const config = { apiKey: 'sk-speech', baseUrl: 'https://api.example.com/v1/' }
    const restore = stubOpenAiReplica(config)
    vi.mocked(inferenceServiceProvidersService.listRemote).mockResolvedValue([{
      id: instanceId,
      definitionId: 'openai-compatible-audio-speech',
      config,
      updatedAt: '2026-01-02T00:00:00.000Z',
      deletedAt: null,
    }])

    try {
      await configStore.syncProviders()
      expect(configStore.providers[instanceId]?.config).toEqual(config)
    }
    finally {
      restore()
    }
  })

  // ROOT CAUSE:
  //
  // A model request kept a reference to its runtime entry across an await.
  // A synced snapshot replaced that entry before the request completed. The
  // request then wrote ready to the detached entry and left the current entry
  // in loading state.
  it('updates the current runtime entry after a synced snapshot replaces it', async () => {
    const store = useProviderStore()
    const request = store.fetchModelsForProvider('official-provider')

    expect(store.providerRuntimeState['official-provider']?.modelStatus).toBe('loading')

    store.providerRuntimeState['official-provider'] = {
      models: [],
      defaultModel: null,
      modelStatus: 'loading',
      modelError: null,
    }

    await request

    expect(store.providerRuntimeState['official-provider']?.modelStatus).toBe('ready')
    expect(store.providerRuntimeState['official-provider']?.modelError).toBeNull()
    expect(store.providerRuntimeState['official-provider']?.models).toEqual([
      expect.objectContaining({ id: 'auto' }),
    ])
  })

  // ROOT CAUSE:
  //
  // Speech startup previously had both an immediate watcher and a mounted
  // refresh. Multiple renderers could also request the same catalog through
  // the synchronized provider action. Each caller created its own request.
  //
  // We keep one leader-owned request per provider, model, and configuration
  // until it settles, so concurrent callers share the same result.
  it('shares concurrent voice catalog requests', async () => {
    const store = useProviderStore()
    useAuthStore().$patch(createAuthenticatedState())
    let resolveRequest: ((response: Response) => void) | undefined
    const fetchMock = vi.fn(() => new Promise<Response>((resolve) => {
      resolveRequest = resolve
    }))
    vi.stubGlobal('fetch', fetchMock)

    try {
      const first = store.listProviderVoices(OFFICIAL_SPEECH_PROVIDER_ID, 'auto')
      const second = store.listProviderVoices(OFFICIAL_SPEECH_PROVIDER_ID, 'auto')

      await vi.waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(1))
      resolveRequest?.(new Response(JSON.stringify({ voices: [], recommended: {} }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      }))

      await expect(Promise.all([first, second])).resolves.toEqual([[], []])
      expect(fetchMock).toHaveBeenCalledTimes(1)
    }
    finally {
      vi.unstubAllGlobals()
    }
  })

  // https://github.com/moeru-ai/airi/pull/2490#discussion_r3959813216
  // ROOT CAUSE:
  //
  // The speech settings page can request an official voice catalog before the
  // authenticated session is ready. A tokenless task then occupies the shared
  // in-flight slot and can absorb the first authenticated retry.
  //
  // Before: the provider starts the official request without an authenticated
  // access token.
  //
  // We fixed this at the provider boundary. Authentication-owned providers do
  // not create an in-flight task until the session and token are both ready.
  it('does not start auth-owned voice requests before the session has a token', async () => {
    const store = useProviderStore()
    const authStore = useAuthStore()
    const voiceRequests: string[] = []
    const fetchMock = vi.fn<typeof fetch>(async (input) => {
      const url = String(input)
      if (url.includes('/api/v1/audio/voices')) {
        voiceRequests.push(url)
        return Response.json({ recommended: {}, voices: [] })
      }
      return Response.json({ flux: 0 })
    })
    vi.stubGlobal('fetch', fetchMock)

    try {
      await expect(store.listProviderVoices(OFFICIAL_SPEECH_PROVIDER_ID, 'auto')).resolves.toEqual([])
      expect(voiceRequests).toHaveLength(0)

      authStore.token = 'restored-access-token'
      await expect(store.listProviderVoices(OFFICIAL_SPEECH_PROVIDER_ID, 'auto')).resolves.toEqual([])
      expect(voiceRequests).toHaveLength(0)

      authStore.$patch(createAuthenticatedState())
      await expect(store.listProviderVoices(OFFICIAL_SPEECH_PROVIDER_ID, 'auto')).resolves.toEqual([])
      expect(voiceRequests).toHaveLength(1)
    }
    finally {
      vi.unstubAllGlobals()
    }
  })

  // https://github.com/moeru-ai/airi/pull/2490#discussion_r3960349395
  // ROOT CAUSE:
  // A detached catalog task survived logout and occupied the next session's
  // in-flight slot. Session changes must isolate requests and stale errors.
  it.each([200, 401])('discards the previous session voice response with status %i', async (status) => {
    const store = useProviderStore()
    const auth = useAuthStore()
    auth.$patch(createAuthenticatedState())
    const { promise: oldResponse, resolve: finishOld } = Promise.withResolvers<Response>()
    let requests = 0
    let oldSignal: AbortSignal | null | undefined
    vi.stubGlobal('fetch', vi.fn<typeof fetch>(async (_input, options) => {
      requests++
      if (requests === 1) {
        oldSignal = options?.signal
        return oldResponse
      }
      return Response.json({ recommended: {}, voices: [{ id: 'new-voice', name: 'New voice', languages: [] }] })
    }))
    const oldLoad = store.listProviderVoices(OFFICIAL_SPEECH_PROVIDER_ID, 'auto')
    try {
      await vi.waitFor(() => expect(requests).toBe(1))
      auth.$patch({ user: null, session: null, token: null })
      expect(oldSignal?.aborted).toBe(true)
      auth.$patch({ ...createAuthenticatedState(), token: 'new-access-token' })
      const newLoad = store.listProviderVoices(OFFICIAL_SPEECH_PROVIDER_ID, 'auto')
      await vi.waitFor(() => expect(requests).toBe(2))
      expect((await newLoad)?.[0]?.id).toBe('new-voice')
      finishOld(Response.json({ recommended: {}, voices: [{ id: 'old-voice', name: 'Old voice', languages: [] }] }, { status }))
      await expect(oldLoad).resolves.toBeUndefined()
    }
    finally {
      finishOld(Response.json({ voices: [], recommended: {} }))
      await oldLoad.catch(() => {})
      vi.unstubAllGlobals()
    }
  })
  // https://github.com/moeru-ai/airi/pull/2490#discussion_r3960674489
  // ROOT CAUSE: Token rotation aborted discovery without a new login hook.
  it('restarts an interrupted catalog after token rotation in the same session', async () => {
    const store = useProviderStore()
    const auth = useAuthStore()
    auth.$patch(createAuthenticatedState())
    let requests = 0
    vi.stubGlobal('fetch', vi.fn<typeof fetch>(async (_input, options) => {
      requests++
      if (requests === 1) {
        return new Promise<Response>((_resolve, reject) => {
          options?.signal?.addEventListener('abort', () => reject(options.signal?.reason), { once: true })
        })
      }
      return Response.json({ recommended: {}, voices: [{ id: 'rotated', name: 'Rotated', languages: [] }] })
    }))
    try {
      const loading = store.listProviderVoices(OFFICIAL_SPEECH_PROVIDER_ID, 'auto')
      await vi.waitFor(() => expect(requests).toBe(1))
      const duplicate = store.listProviderVoices(OFFICIAL_SPEECH_PROVIDER_ID, 'auto')
      auth.token = 'rotated-token'
      expect((await loading)?.[0]?.id).toBe('rotated')
      expect((await duplicate)?.[0]?.id).toBe('rotated')
      expect(requests).toBe(2)
    }
    finally {
      vi.unstubAllGlobals()
    }
  })
  // https://github.com/moeru-ai/airi/pull/2490#discussion_r3963756328
  // ROOT CAUSE: Deserialized session objects changed identity without changing request ownership.
  it('keeps the replacement request alive when refresh replaces same-ID session objects', async () => {
    const store = useProviderStore()
    const auth = useAuthStore()
    auth.$patch(createAuthenticatedState())
    let requests = 0
    let replacementSignal: AbortSignal | null | undefined
    let finish!: (response: Response) => void
    vi.stubGlobal('fetch', vi.fn<typeof fetch>(async (_input, options) => {
      requests++
      return new Promise<Response>((resolve, reject) => {
        options?.signal?.addEventListener('abort', () => reject(options.signal?.reason), { once: true })
        if (requests === 2) {
          replacementSignal = options?.signal
          finish = resolve
        }
      })
    }))
    const loading = store.listProviderVoices(OFFICIAL_SPEECH_PROVIDER_ID, 'auto')
    try {
      await vi.waitFor(() => expect(requests).toBe(1))
      auth.token = 'renewed-token'
      await vi.waitFor(() => expect(requests).toBe(2))
      const refreshed = createAuthenticatedState()
      auth.user = refreshed.user
      auth.session = refreshed.session
      expect(replacementSignal?.aborted).toBe(false)
      finish(Response.json({ voices: [{ id: 'renewed', name: 'Renewed', languages: [] }] }))
      expect((await loading)?.[0]?.id).toBe('renewed')
      expect(requests).toBe(2)
    }
    finally {
      finish?.(Response.json({ voices: [] }))
      await loading
      vi.unstubAllGlobals()
    }
  })
})
