# 地图陪伴精灵（WoW Map Companion）

正式服 Lua 插件，无需其他插件、AI 服务或桌面伴侣。

## 功能

- 在屏幕顶部居中、向下偏移 72 个 UI 单位的位置显示半透明面板。
- 面板顶部显示玩家当前地图名称，并持续保留。
- 登录、重载 UI、跨区域、进入室内和传送后自动刷新。
- 优先显示 `C_Map.GetBestMapForUnit("player")` 对应的地图名称；不可用时回退到当前区域名称。
- 地图数据加载较慢时，在事件后 0.25、1、2、5 秒重试；无每帧轮询。
- 浏览世界地图的其他区域不会改变玩家位置来源。多层地图可能显示当前楼层的地图名称。
- 面板不接收鼠标操作，不会阻挡点击下方游戏画面。

## 安装

1. 退出游戏。
2. 将整个 `WoWMapCompanion` 文件夹复制到正式服的 `World of Warcraft\_retail_\Interface\AddOns\`。
3. 确保目录层级如下，不要多嵌套一层同名文件夹：

```text
_retail_\Interface\AddOns\WoWMapCompanion\
    WoWMapCompanion.toc
    WoWMapCompanion.lua
    README.md
```

4. 启动游戏，在角色选择界面的“插件”列表中启用“地图陪伴精灵 / WoW Map Companion”。
5. 进入角色后即可看到地图名。已加载插件后的代码修改可通过 `/reload` 生效。

## 调整位置

修改 `WoWMapCompanion.lua` 开头的常量，然后在游戏内输入 `/reload`：

```lua
local PANEL_WIDTH = 360
local PANEL_HEIGHT = 58
local OFFSET_X = 0
local OFFSET_Y = -72
```

`OFFSET_X` 为正向右、为负向左；`OFFSET_Y` 越负，面板越向下。坐标随游戏 UI 缩放变化。

## 版本与验收

TOC 声明接口版本 `120105, 120100`，面向正式服 12.1.5 / 12.1.0。地区和更新进度可能不同。
若提示版本过期，可在游戏里输入 `/dump select(4, GetBuildInfo())` 查看实际接口号；再根据客户端版本核对 TOC，或在插件列表勾选“加载过期插件”。修改接口号仅改变版本声明，不代表自动获得兼容性。

已按公开的正式服 API 编写；本工作环境未运行 WoW 客户端，实际显示和事件行为仍需游戏内验收：

1. 登录和 `/reload` 后显示当前地图。
2. 跨区域或传送后，名称自动更新。
3. 进入副本、室内或多层地图，确认显示合理；数据不可用时显示区域名。
4. 打开世界地图浏览远处区域，面板仍显示角色所在地图。
5. 战斗中跨区域时无 Lua 错误，且面板不阻挡鼠标操作。

## API 参考

以下链接是暴雪客户端导出文档的社区镜像：

- [地图接口](https://github.com/Gethe/wow-ui-source/blob/live/Interface/AddOns/Blizzard_APIDocumentationGenerated/MapDocumentation.lua)
- [区域名称接口](https://github.com/Gethe/wow-ui-source/blob/live/Interface/AddOns/Blizzard_APIDocumentationGenerated/ZoneScriptDocumentation.lua)
