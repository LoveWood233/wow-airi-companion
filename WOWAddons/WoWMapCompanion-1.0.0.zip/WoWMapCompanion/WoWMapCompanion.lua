-- Retail WoW addon. No external libraries, network access or saved variables.
-- UI coordinates are scaled by the game's UI scale setting.
local PANEL_WIDTH = 360
local PANEL_HEIGHT = 58
local OFFSET_X = 0
local OFFSET_Y = -72 -- Negative values move the panel down from the screen top.

local locale = GetLocale()
local isChinese = locale == "zhCN" or locale == "zhTW"
local pendingText = isChinese and "正在获取地图…" or "Locating map..."
local unknownText = isChinese and "当前位置暂不可用" or "Location unavailable"

local panel = CreateFrame("Frame", "WoWMapCompanionPanel", UIParent)
panel:SetSize(PANEL_WIDTH, PANEL_HEIGHT)
panel:SetPoint("TOP", UIParent, "TOP", OFFSET_X, OFFSET_Y)
panel:SetFrameStrata("MEDIUM")
panel:EnableMouse(false)

local background = panel:CreateTexture(nil, "BACKGROUND")
background:SetAllPoints(panel)
background:SetColorTexture(0.035, 0.055, 0.085, 0.78)

local accent = panel:CreateTexture(nil, "BORDER")
accent:SetPoint("TOPLEFT", panel, "TOPLEFT", 0, 0)
accent:SetPoint("TOPRIGHT", panel, "TOPRIGHT", 0, 0)
accent:SetHeight(2)
accent:SetColorTexture(0.87, 0.71, 0.36, 0.95)

-- Use the game's localized font so Chinese clients render names correctly.
local mapLabel = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
mapLabel:SetPoint("TOPLEFT", panel, "TOPLEFT", 12, -10)
mapLabel:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -12, -10)
mapLabel:SetJustifyH("CENTER")
mapLabel:SetJustifyV("TOP")
mapLabel:SetWordWrap(true)
mapLabel:SetTextColor(1, 0.87, 0.56)
mapLabel:SetText(pendingText)

local function RefreshMap()
    -- Query the player's location, not the map currently browsed in the UI.
    local mapID = C_Map.GetBestMapForUnit("player")
    local info = mapID and C_Map.GetMapInfo(mapID)
    local name = info and info.name

    if not name or name == "" then
        name = GetRealZoneText()
    end
    if not name or name == "" then
        name = GetZoneText()
    end
    if not name or name == "" then
        name = unknownText
    end

    mapLabel:SetText(name)
    -- Keep the top edge fixed while allowing unusually long names to wrap.
    panel:SetHeight(math.max(PANEL_HEIGHT, mapLabel:GetStringHeight() + 22))
end

local refreshTimers = {}
local function CancelRefreshTimers()
    for _, timer in ipairs(refreshTimers) do
        timer:Cancel()
    end
    wipe(refreshTimers)
end

local function ScheduleRefresh()
    CancelRefreshTimers()
    RefreshMap()
    -- Zone events may arrive before map data settles after loading/teleporting.
    -- A new event cancels old retries, keeping rapid transitions inexpensive.
    for _, delay in ipairs({ 0.25, 1, 2, 5 }) do
        refreshTimers[#refreshTimers + 1] = C_Timer.NewTimer(delay, RefreshMap)
    end
end

panel:RegisterEvent("PLAYER_ENTERING_WORLD")
panel:RegisterEvent("PLAYER_LEAVING_WORLD")
panel:RegisterEvent("ZONE_CHANGED_NEW_AREA")
panel:RegisterEvent("ZONE_CHANGED")
panel:RegisterEvent("ZONE_CHANGED_INDOORS")
panel:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LEAVING_WORLD" then
        CancelRefreshTimers()
        mapLabel:SetText(pendingText)
        return
    end
    ScheduleRefresh()
end)
